export default function PrivacyPage() {
  return (
    <div className="py-12 px-4 max-w-3xl mx-auto">
      <h1 className="font-display text-4xl mb-6">Privacy</h1>
      <p>
        We use behavior and amenity signals (light, noise, walkability, layout) — never protected traits.
        We always present multiple areas with clear reasons, and we honor consent, minimization, access, and deletion under PIPEDA/BC PIPA.
      </p>
    </div>
  );
}

import caseStudies from '../../data/case-studies.json';
import CaseCard from '../components/CaseCard';

export default function CaseStudiesPage() {
  return (
    <div className="py-12 px-4 max-w-5xl mx-auto">
      <h1 className="font-display text-4xl mb-8">Case Studies</h1>
      <div className="grid gap-6">
        {caseStudies.map((cs: any) => (
          <CaseCard key={cs.id} study={cs} />
        ))}
      </div>
    </div>
  );
}

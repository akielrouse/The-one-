import Link from 'next/link';
import ComplianceNote from '../components/ComplianceNote';

export default function ForAgentsPage() {
  return (
    <div className="py-12 px-4 max-w-4xl mx-auto">
      <h1 className="font-display text-4xl mb-6">For Agents</h1>
      <p className="mb-4 text-xl">Stop wasting tours. Start showing the right homes.</p>
      <p className="mb-4">Buyer brief, six matches with reasons, Tour Builder, ROI dashboard.</p>
      <p className="mb-4">Scan → 7 minutes → 3 ready-to-tour homes.</p>
      <p className="mb-4 italic">If Time-to-Tour doesn’t drop in 30 days, we credit a month.</p>
      <Link href="/" className="bg-accent text-white py-3 px-6 rounded hover:bg-opacity-90">
        Get 20 free intakes
      </Link>
      <div className="mt-8">
        <ComplianceNote />
      </div>
    </div>
  );
}

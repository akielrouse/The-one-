import HowItWorksSteps from '../components/HowItWorksSteps';
import ComplianceNote from '../components/ComplianceNote';
import Link from 'next/link';

export default function HowItWorksPage() {
  return (
    <div className="py-12 px-4">
      <h1 className="font-display text-4xl mb-8 text-center">How it Works</h1>
      <HowItWorksSteps />
      <div className="mt-8 text-center">
        <Link href="/for-agents" className="bg-accent text-white py-3 px-6 rounded hover:bg-opacity-90">
          Start your pilot
        </Link>
      </div>
      <div className="mt-8">
        <ComplianceNote />
      </div>
    </div>
  );
}

import Link from 'next/link';
import ComplianceNote from '../components/ComplianceNote';

export default function ForDevelopersPage() {
  return (
    <div className="py-12 px-4 max-w-4xl mx-auto">
      <h1 className="font-display text-4xl mb-6">For Developers</h1>
      <p className="mb-4 text-xl">Segment clarity in two weeks.</p>
      <p className="mb-4">Who buys, why, message pillars, amenity trade-offs, absorption plan.</p>
      <Link href="/contact" className="bg-accent text-white py-3 px-6 rounded hover:bg-opacity-90">
        Book a 30-min discovery
      </Link>
      <div className="mt-8">
        <ComplianceNote />
      </div>
    </div>
  );
}

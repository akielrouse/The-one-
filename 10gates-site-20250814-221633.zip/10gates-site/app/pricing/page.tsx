import PricingTable from '../components/PricingTable';
import ComplianceNote from '../components/ComplianceNote';

export default function PricingPage() {
  return (
    <div className="py-12 px-4">
      <h1 className="font-display text-4xl mb-8 text-center">Pricing</h1>
      <PricingTable />
      <div className="mt-8 text-center">
        <p className="italic">Add-on: Verified listing page C$99/listing. Briefs: From C$10k; request scope.</p>
      </div>
      <div className="mt-8">
        <ComplianceNote />
      </div>
    </div>
  );
}

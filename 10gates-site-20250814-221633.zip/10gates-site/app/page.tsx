import Hero from './components/Hero';
import ValueCards from './components/ValueCards';
import StatChips from './components/StatChips';
import ComplianceNote from './components/ComplianceNote';
import Link from 'next/link';

export default function HomePage() {
  return (
    <div>
      <Hero />
      <section className="py-16 px-4">
        <ValueCards />
      </section>
      <section className="py-8 px-4">
        <StatChips />
      </section>
      <section className="py-8 px-4">
        <p className="text-lg italic max-w-2xl mx-auto text-center">
          “Because you chose evening light and quiet lanes, we prioritized SW exposures on calm streets with covered terraces.”
        </p>
      </section>
      <section className="py-8 px-4">
        <p className="text-center">We reorder galleries to what matters to each buyer.</p>
      </section>
      <section className="py-8 px-4 text-center">
        <ComplianceNote />
      </section>
      <section className="py-12 px-4 text-center">
        <Link href="/for-agents" className="bg-accent text-white py-3 px-6 rounded hover:bg-opacity-90">
          Get 20 free intakes
        </Link>
      </section>
    </div>
  );
}

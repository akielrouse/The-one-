import LeadForm from '../components/LeadForm';

export default function ContactPage() {
  return (
    <div className="py-12 px-4">
      <h1 className="font-display text-4xl mb-6">Contact</h1>
      <p className="mb-4">Tell us your office size; we’ll set up your pilot.</p>
      <LeadForm />
    </div>
  );
}
